#!/usr/bin/env bash
# Installs system packages NetScope uses (Debian/Ubuntu/Kali). Run once: ./install_linux_tools.sh
set -euo pipefail
if ! command -v apt-get >/dev/null; then
  echo "Not an apt-based system. Install manually: python3, python3-venv, nmap, tshark, whois, traceroute, gcc,"
  echo "and Qt xcb libs (libxcb-cursor0, libegl1, libxkbcommon-x11-0)."; exit 1
fi
SUDO=""; [[ $EUID -ne 0 ]] && SUDO="sudo"
$SUDO apt-get update
# Core + Qt runtime libraries PySide6 needs on Linux
$SUDO apt-get install -y python3 python3-venv python3-pip nmap traceroute whois gcc \
  libegl1 libgl1 libxkbcommon-x11-0 libxcb-cursor0 libxcb-icccm4 libxcb-keysyms1 libxcb-shape0 libdbus-1-3
# Optional tools (skipped silently if not in your repos)
for pkg in tshark rustscan; do $SUDO apt-get install -y "$pkg" || echo "Optional package $pkg unavailable - skipping."; done
echo "Done. Start NetScope with ./run_netscope_linux.sh"
