#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
command -v python3 >/dev/null || { echo "Run ./install_linux_tools.sh first."; exit 1; }
python3 -c 'import sys; sys.exit(0 if sys.version_info>=(3,10) else 1)' || { echo "Python 3.10+ required."; exit 1; }
# Diagnostics and tests need no virtualenv or internet.
case "${1:-}" in --check|--selftest|--build-c) exec python3 netscope.py "$@";; esac
[[ -x .venv/bin/python ]] || python3 -m venv .venv
.venv/bin/python -m pip install --disable-pip-version-check -q -r requirements.txt
.venv/bin/python netscope.py --build-c >/dev/null 2>&1 || true   # optional C helper
# Wayland fallback: force X11 plugin if no display plugin works
export QT_QPA_PLATFORM="${QT_QPA_PLATFORM:-}"
exec .venv/bin/python netscope.py "$@"
