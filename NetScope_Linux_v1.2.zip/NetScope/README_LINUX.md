# NetScope 1.2 for Linux (Kali / Debian / Ubuntu)
Authorized use only - scan systems you own or have written permission to test.

    chmod +x *.sh
    ./install_linux_tools.sh      # once: nmap, traceroute, whois, tshark, Qt libs (needs sudo)
    ./run_netscope_linux.sh       # creates .venv, installs Python packages, starts the GUI

Other commands: `./run_netscope_linux.sh --check` | `--selftest` | `--build-c`

Tips
- Do not run the whole GUI as root. For SYN/OS scans use: `sudo setcap cap_net_raw,cap_net_admin+eip $(which nmap)`
  or run only Nmap-heavy work with elevated rights per your policy.
- TShark capture permissions: `sudo dpkg-reconfigure wireshark-common`, then add your user to group `wireshark`.
- "Could not load the Qt platform plugin xcb": re-run install_linux_tools.sh (needs libxcb-cursor0).
  On Wayland you can try `QT_QPA_PLATFORM=xcb ./run_netscope_linux.sh`.
- Optional menu entry: `sed "s#__DIR__#$PWD#" netscope.desktop.template > ~/.local/share/applications/netscope.desktop`
- Data is stored in `data/` next to netscope.py. Limitations are the same as the Windows build (see README in that ZIP):
  exposure findings are heuristics, not CVE proof; unsupported modules are reported as skipped.

## What's new in 1.2
- **Security grade (A-F)** per host and for the whole network, with a trend over time.
- **Attack paths** - plain-language stories that chain exposed services (hypothetical; nothing is exploited).
- **Fix-it playbooks** - copy-paste Windows/Linux commands per finding, plus **Re-scan to verify**. NetScope never runs the commands for you.
- **Time Machine** - replay saved scans with a slider / Play button; see hosts appear or vanish and ports open or close.
- **Trusted baseline + rogue-device alarm** - banner on the Dashboard and red rings on the radar.
- **Network Radar** - animated live map. Closer to the centre = lower grade; attack-path overlay; hover or click a host.
- **Command palette (Ctrl+K)** - jump to any page, tool, host, attack path or action.
- **Tamper-evident reports** - every export is sealed in a hash chain (+ local HMAC key). Use *Verify report...* to prove a
  report is unchanged. Keep `<report>.seal.json` next to the report. PDF/HTML/JSON include an executive summary.
- **Light/dark theme** (remembered), page fade transitions, animated counters.

Notes: seals prove integrity on the machine that created them (key in `data/report.key`). Grades and attack paths are
exposure heuristics from scanned ports, not CVE verification. Run a scan (or Network Discovery) first so the new pages have data.
