#ifndef NETSCOPE_H
#define NETSCOPE_H
int ns_add(int a, int b);
const char *ns_version(void);
#endif
