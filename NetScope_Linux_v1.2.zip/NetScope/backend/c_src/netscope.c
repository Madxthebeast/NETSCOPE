#include "netscope.h"
int ns_add(int a, int b) { return a + b; }
const char *ns_version(void) { return "NetScope-C/1.0"; }
